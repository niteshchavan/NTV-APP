package com.nitesh.ntv;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.DividerItemDecoration;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class YTDownloads extends AppCompatActivity {

    private static final String TAG = "Downloads";
    private RecyclerView recyclerView;
    private PlayerView playerView;
    private ExoPlayer player;
    private PowerManager.WakeLock wakeLock;

    private VideoAdapter videoAdapter;



    public void onFullscreenClicked(View view) {
        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            // Set PlayerView to fullscreen size
            ViewGroup.LayoutParams params = playerView.getLayoutParams();
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.height = ViewGroup.LayoutParams.MATCH_PARENT;
            playerView.setLayoutParams(params);
            // Hide system bars for a more immersive experience (optional)
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            // Hide the RecyclerView
            findViewById(R.id.recycler_view).setVisibility(View.GONE);
            hideSystemUI();
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            // Reset PlayerView to original size (optional)
            ViewGroup.LayoutParams params = playerView.getLayoutParams();
            // Set your original width and height here (based on your layout)
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.height = 700;

            playerView.setLayoutParams(params);
            // Show system bars again
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);

            // Show the RecyclerView
            findViewById(R.id.recycler_view).setVisibility(View.VISIBLE);
            showSystemUI();
        }
        // Acquire wake lock to keep screen on during playback
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyApp:AudioPlayback");
    }

    private int uiOptions;
    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        uiOptions = decorView.getSystemUiVisibility();
        int newUiOptions = uiOptions;
        newUiOptions |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
        newUiOptions |= View.SYSTEM_UI_FLAG_FULLSCREEN;
        newUiOptions |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        newUiOptions |= View.SYSTEM_UI_FLAG_IMMERSIVE;
        newUiOptions |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(newUiOptions);
    }
    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        uiOptions = decorView.getSystemUiVisibility();
        int newUiOptions = uiOptions;
        newUiOptions &= ~View.SYSTEM_UI_FLAG_LOW_PROFILE;
        newUiOptions &= ~View.SYSTEM_UI_FLAG_FULLSCREEN;
        newUiOptions &= ~View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        newUiOptions &= ~View.SYSTEM_UI_FLAG_IMMERSIVE;
        newUiOptions &= ~View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(newUiOptions);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yt_downloads);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        playerView = findViewById(R.id.video_view);
        player = new ExoPlayer.Builder(this).build(); // Ensure player is initialized here
        playerView.setPlayer(player); // Attach the player to the PlayerView


        // Load the playlist (downloaded videos)
        loadPlaylist();

        // Add back button handling
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Start MainActivity when back is pressed
                Intent intent = new Intent(YTDownloads.this, IntroActivity.class);
                // Set flags to avoid going back to YTDownloads after navigating to MainActivity
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish(); // Optional: Finish current activity if you don't want it in the back stack
            }
        });
    }
    private void loadPlaylist() {
        // Define the path to your downloaded videos folder
        File downloadsFolder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "youtubedl-android");

        // Check if the folder exists, if not, create it
        if (!downloadsFolder.exists()) {
            boolean isCreated = downloadsFolder.mkdirs();
            if (isCreated) {
                Toast.makeText(this, "Folder created: " + downloadsFolder.getAbsolutePath(), Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Folder created: " + downloadsFolder.getAbsolutePath());
            } else {
                Toast.makeText(this, "Failed to create folder", Toast.LENGTH_SHORT).show();
            }
        }

        // Get all files in the folder (allow all extensions)
        File[] videoFiles = downloadsFolder.listFiles(File::isFile);

        if (videoFiles != null && videoFiles.length > 0) {
            // Sort files by last modified date (newest first)
            Arrays.sort(videoFiles, (file1, file2) -> Long.compare(file2.lastModified(), file1.lastModified()));

            // Convert to a list for the adapter
            List<File> videoList = new ArrayList<>(Arrays.asList(videoFiles));

            // Set up the adapter with the sorted video list
            videoAdapter = new VideoAdapter(videoList, this);
            recyclerView.setAdapter(videoAdapter);

            // Add dividers between items in the RecyclerView
            DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL);
            recyclerView.addItemDecoration(dividerItemDecoration);
        } else {
            Toast.makeText(this, "No files available", Toast.LENGTH_SHORT).show();
        }
    }

    public void playVideo(String videoPath) {
        // Ensure the video path is valid
        if (!TextUtils.isEmpty(videoPath)) {
            // Create MediaItem from the video file path
            MediaItem mediaItem = MediaItem.fromUri("file://" + videoPath);

            // Set the MediaItem to the player
            player.setMediaItem(mediaItem);
            player.prepare();
            player.play();
            acquireWakeLock();
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            player.addListener(new Player.Listener() {
                @Override
                public void onPlaybackStateChanged(int playbackState) {
                    if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) {
                        releaseWakeLock();
                    }
                }
            });
        } else {
            Toast.makeText(this, "Invalid video path", Toast.LENGTH_SHORT).show();
        }
    }

    private void acquireWakeLock() {
        if (wakeLock == null) {
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyApp:AudioPlayback");
        }
        if (!wakeLock.isHeld()) {
            wakeLock.acquire();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release(); // Release the player to free up resources
            player = null;
            releaseWakeLock();
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();

        }
    }


}
