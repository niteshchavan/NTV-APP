package com.nitesh.ntv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    private final List<File> videoFiles;
    private final Context context;

    public VideoAdapter(List<File> videoFiles, Context context) {
        this.videoFiles = videoFiles;
        this.context = context;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout
        View view = LayoutInflater.from(context).inflate(R.layout.item_video, parent, false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
        // Set the file name as the text for the TextView
        File videoFile = videoFiles.get(position);
        holder.videoNameTextView.setText(videoFile.getName());

        // Set an OnClickListener to play the selected video
        holder.itemView.setOnClickListener(v -> {
            // Call the playVideo method of YTDownloads
            if (context instanceof YTDownloads) {
                ((YTDownloads) context).playVideo(videoFile.getAbsolutePath());
            }
        });
    }

    @Override
    public int getItemCount() {
        return videoFiles.size();
    }

    public static class VideoViewHolder extends RecyclerView.ViewHolder {
        TextView videoNameTextView;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            videoNameTextView = itemView.findViewById(R.id.video_name);
        }
    }
}
